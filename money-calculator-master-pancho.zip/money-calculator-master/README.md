# Money Calculator
## Summary
A program that allows the user to make conversion between currencies with a graphical interface. 
## How are currencies loaded and converted?
The currencies available in the program are fetched from an external **API**. Additionally, conversions are calculated based on exchange rates provided by an external **API** too, so the conversion rates are recent. 
## Functionalities
The program has two main functionalities:
 - Convert a given amount from one currency to another one with recent exchange rates.
 - Convert  a given amount from one currency to another one using historical rates from an specific date.

## API keys

The application reads API keys from environment variables instead of storing them in the source code:

- `CURRENCYLAYER_API_KEY`: Currencylayer API key
- `EXCHANGERATES_API_KEY`: ExchangeratesAPI key

On Windows PowerShell, you can set them for the current terminal session with:

```powershell
$env:CURRENCYLAYER_API_KEY="your_currencylayer_key"
$env:EXCHANGERATES_API_KEY="your_exchangerates_key"
```
